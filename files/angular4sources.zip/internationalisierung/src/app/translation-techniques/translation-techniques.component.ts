import { Component } from '@angular/core';

@Component({
  selector: 'ch-translation-techniques',
  templateUrl: './translation-techniques.component.html',
  styleUrls: ['./translation-techniques.component.css']
})
export class TranslationTechniquesComponent {
  greeting = 'Angular';
  user = 'John';
}
