/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { TranslationTechniquesComponent } from './translation-techniques.component';

describe('Component: TranslationTechniques', () => {
  it('should create an instance', () => {
    let component = new TranslationTechniquesComponent();
    expect(component).toBeTruthy();
  });
});
