export interface User {
  firstName?: string;
  lastName?: string;
  sex?: string;
}