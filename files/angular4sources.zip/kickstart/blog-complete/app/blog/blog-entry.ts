export class BlogEntry {
  title: string;
  text: string;
  image: string;
}
