const name = 'Babel';
console.log('Hello ${name}')