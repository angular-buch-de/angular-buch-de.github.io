'use strict';

// Destructuring Variables
const user = {
    firstName: 'John',
    lastName: 'Doe',
    city: 'New York'
};
console.log(`Hi, my name is ${user.firstName} ${user.lastName}`);

console.log(`Contact card:
Name: ${user.firstName}
Vorname: ${user.lastName}
Stadt: ${user.city}`);
