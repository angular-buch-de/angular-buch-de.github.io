function NameService () {
}
NameService.prototype.getName = function(){
  return "John Doe";
};

NameService.prototype.getRoles = function() {
  return  ["admin", "user"];
}

