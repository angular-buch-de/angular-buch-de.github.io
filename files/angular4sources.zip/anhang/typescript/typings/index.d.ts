/**
 * Die beiden Deklarationen sind nur notwendig, wenn keine echten TypeDefinitions über das npm installiert wurden
 */

//declare module 'lodash';

//declare var _ : any;