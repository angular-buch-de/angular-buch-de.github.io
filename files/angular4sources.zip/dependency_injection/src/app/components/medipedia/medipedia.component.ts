import { Component } from '@angular/core';

@Component({
  selector: 'ch-medipedia',
  templateUrl: 'medipedia.component.html',
  styleUrls: ['medipedia.component.css'],
})
export class MedipediaComponent {


}
