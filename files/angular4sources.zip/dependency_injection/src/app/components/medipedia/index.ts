export * from './medipedia.component';
