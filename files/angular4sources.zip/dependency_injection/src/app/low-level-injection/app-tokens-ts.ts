import {InjectionToken} from '@angular/core';
export const RANDOM_VALUE = new InjectionToken<number>('random-value');
