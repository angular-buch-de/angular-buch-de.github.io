
export const environment = {
  production: false,
  e2eMode: true
};
