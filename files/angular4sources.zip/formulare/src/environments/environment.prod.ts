export const environment = {
  production: true,
  e2eMode: false
};
