export * from './first-form-two-way.component';
