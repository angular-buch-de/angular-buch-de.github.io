export * from './generated-form.component';
