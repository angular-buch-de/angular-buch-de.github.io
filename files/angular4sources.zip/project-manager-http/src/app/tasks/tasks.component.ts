import {Component} from '@angular/core';

@Component({
  selector: 'tasks',
  template: ' <router-outlet></router-outlet>',
})
export class TasksComponent {
  constructor() {
  }
}
