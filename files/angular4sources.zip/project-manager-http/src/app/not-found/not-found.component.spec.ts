
import { NotFoundComponent } from './not-found.component';

describe('Component: NotFound', () => {
  it('should create an instance', () => {
    const component = new NotFoundComponent();
    expect(component).toBeTruthy();
  });
});
