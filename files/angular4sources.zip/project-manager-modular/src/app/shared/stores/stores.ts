import {Store} from "./generic-store";
import {Task} from "../../shared/models/model-interfaces";

export class TaskStore extends Store<Task> {

}