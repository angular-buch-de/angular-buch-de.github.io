/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { BasicsComponent } from './basics.component';

describe('Component: Basics', () => {
  it('should create an instance', () => {
    const component = new BasicsComponent();
    expect(component).toBeTruthy();
  });
});
