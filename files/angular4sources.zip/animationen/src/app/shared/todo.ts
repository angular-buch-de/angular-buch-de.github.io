export interface Todo {
  text: string;
  completed: boolean;
}