/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { KeyframesComponent } from './keyframes.component';

describe('Component: Keyframes', () => {
  it('should create an instance', () => {
    const component = new KeyframesComponent();
    expect(component).toBeTruthy();
  });
});
