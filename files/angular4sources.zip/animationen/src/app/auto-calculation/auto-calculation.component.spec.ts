/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { AutoCalculationComponent } from './auto-calculation.component';

describe('Component: AutoCalculation', () => {
  it('should create an instance', () => {
    const component = new AutoCalculationComponent();
    expect(component).toBeTruthy();
  });
});
