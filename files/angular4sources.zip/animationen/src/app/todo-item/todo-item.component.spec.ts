/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { TodoItemComponent } from './todo-item.component';

describe('Component: TodoItem', () => {
  it('should create an instance', () => {
    const component = new TodoItemComponent();
    expect(component).toBeTruthy();
  });
});
