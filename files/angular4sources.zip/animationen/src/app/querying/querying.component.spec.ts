/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { QueryingComponent } from './querying.component';

describe('Component: Querying', () => {
  it('should create an instance', () => {
    const component = new QueryingComponent();
    expect(component).toBeTruthy();
  });
});
