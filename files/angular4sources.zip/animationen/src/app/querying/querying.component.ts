import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-querying',
  templateUrl: './querying.component.html',
  styleUrls: ['./querying.component.css']
})
export class QueryingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
