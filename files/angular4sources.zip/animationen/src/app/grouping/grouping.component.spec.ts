/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { GroupingComponent } from './grouping.component';

describe('Component: Grouping', () => {
  it('should create an instance', () => {
    const component = new GroupingComponent();
    expect(component).toBeTruthy();
  });
});
