import {Component} from '@angular/core';

@Component({
  selector: 'ch-tabs-demo',
  templateUrl: 'tabs-demo.component.html',
  styleUrls: ['tabs-demo.component.css'],
})
export class TabsDemoComponent {

  constructor() {}

}
