import {Component} from '@angular/core';

@Component({
  selector: 'ch-panel-demo',
  templateUrl: 'panel-demo.component.html'
})
export class PanelDemoComponent {

  constructor() {
  }
}
