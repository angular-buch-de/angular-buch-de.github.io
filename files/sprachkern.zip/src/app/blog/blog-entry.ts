export class BlogEntry {
  constructor(public title: string,
              public image: string,
              public text: string) {

  }
}
